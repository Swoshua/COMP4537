const express = require('express');
const mysql = require('mysql');
const app = express();

var con = mysql.createConnection({
    host: "jos-test.c4ztbtstxmqe.us-east-1.rds.amazonaws.com",
    user: "admin",
    password: "Jerome2020",
    database: "Joshua_Memory_Game"
});

function processQuery (results) {
  let string = JSON.stringify(results);
  return JSON.parse(string);
}
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
  res.setHeader('Access-Control-Allow-Credentials', true);
  next()
});

app.get("/retrieve_score", (req, res) => {
  con.query(`SELECT name, score FROM Player ORDER BY score DESC;`, (error, results, fields) => {
    if (error){
      res.send({'error': error});
    } else {
      res.send({'results': processQuery(results)});
    }
  });
});

app.get('/insert_score', (req, res) => {
  let score = req.query.score;
  let name = req.query.name;
  con.query("INSERT INTO Player (name, score) VALUES (" + con.escape(name) + "," + con.escape(score) + ")", function(err, results, fields) {
      if(err) {
          console.log(err)
          res.send(err)
      }
      res.send(JSON.stringify(results))
  });
});

var PORT = process.env.PORT || 8000;
app.listen(PORT);